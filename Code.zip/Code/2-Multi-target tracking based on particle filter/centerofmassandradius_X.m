function [X_bar,R] = centerofmassandradius_X(X,B,m,n_frame,X_bar,R)
    X1_meanpoint=0;X2_meanpoint=0;
    for n_clusterpoint=1:B(m,n_frame)
        X1_meanpoint=X1_meanpoint+X(1,n_clusterpoint,m,n_frame);
        X2_meanpoint=X2_meanpoint+X(2,n_clusterpoint,m,n_frame);
    end
    X_bar(1,m,n_frame)=X1_meanpoint/B(m,n_frame);
    X_bar(2,m,n_frame)=X2_meanpoint/B(m,n_frame);
    X1_Rpoint=zeros(2,B(m,n_frame));
    for n_clusterpoint=1:B(m,n_frame)
        X1_Rpoint(1,n_clusterpoint)=abs(X(1,n_clusterpoint,m,n_frame)-X_bar(1,m,n_frame));
        X1_Rpoint(2,n_clusterpoint)=abs(X(2,n_clusterpoint,m,n_frame)-X_bar(2,m,n_frame));
    end
    R(:,m,n_frame)=max(X1_Rpoint,[],2); 
end