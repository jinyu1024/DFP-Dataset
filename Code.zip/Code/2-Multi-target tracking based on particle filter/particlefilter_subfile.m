function [W_tilde,Y_tilde,Y_breve,R_tilde,R_Z,Z_bar] = particlefilter_subfile(M_tilde,M_breve,m_tilde,coefficient_RP,r2,B1,W_tilde,Y_tilde,Y_breve,R_tilde,O,Z,...,
B_tilde,Noise_Q,R_Z,Z_bar,X,B,m,n_startframe,n_frame,X_bar,R,cluster_data,Range_resolution,N_range,N_Theta,AoA,periodicity)
    a=['.r' 'or' 'sr' '^r' 'xr' '+r' '*r' 'vr' 'dr'  '>r' '<r'  'pr'];
    b=['.b' 'ob' 'sb' '^b' 'xb' '+b' '*b' 'vb' 'db'  '>b' '<b'  'pb'];
    c=['.k' 'ok' 'sk' '^k' 'xk' '+k' '*k' 'vk' 'dk' '>k' '<k' 'pk'];
    d=['.m' 'om' 'sm' '^m' 'xm' '+m' '*m' 'vm' 'dm' '>m' '<m' 'pm'];
    e=['.c' 'oc' 'sc' '^c' 'xc' '+c' '*c' 'vc' 'dc' '>c' '<c' 'pc'];
    if O(m_tilde,n_frame-1)==0 && O(m_tilde,n_frame)==1
       %% 
        [X_bar,R] = centerofmassandradius_X(X,B,m,n_frame,X_bar,R);
        for index_particle=1:B1
            Y_tilde(1:2,index_particle,m_tilde,n_frame)=[(coefficient_RP(1)*R(1,m,n_frame)+r2(1))*(2*rand-1);(coefficient_RP(2)*R(2,m,n_frame)+r2(2))*(2*rand-1)]+X_bar(1:2,m,n_frame);%
        end
        W_tilde(:,m_tilde,n_frame)=1/B1;
        Y_breve(1:4,m_tilde,n_frame)=Y_tilde(1:4,:,m_tilde,n_frame)*W_tilde(:,m_tilde,n_frame);
        Y1_Rpoint=zeros(2,B1);
        for n_clusterpoint=1:B1
            Y1_Rpoint(1:4,n_clusterpoint)=abs(Y_tilde(1:4,n_clusterpoint,m_tilde,n_frame)-Y_breve(1:4,m_tilde,n_frame));
        end
        R_tilde(1:4,m_tilde,n_frame)=max(Y1_Rpoint,[],2);
    elseif O(m_tilde,n_frame-1)==1 && O(m_tilde,n_frame)==1
       %% 
        A_tilde=[1,0,periodicity,0;0,1,0,periodicity;0,0,1,0;0,0,0,1];
        Y_hat(1:4,1:B1,m_tilde,n_frame)=A_tilde*Y_tilde(1:4,1:B1,m_tilde,n_frame-1)+sqrtm(Noise_Q)*randn(4,B1);
        R_hat=[];value_Rhatascend=[];R_hat_s3=[];P_tilde=[];
        for index_particle=1:B1
            for index_point=1:size(cluster_data,1)
                R_hat(index_particle, index_point)=norm(Y_hat(1:2,index_particle,m_tilde,n_frame)-cluster_data(index_point,1:2).');
            end
        end
        [value_Rhatascend,index_Rhatascend]=sort(R_hat,2,'ascend');
        value_Rhatascend(1:B1,4:index_point)=0;
        R_hat_s3=sum(value_Rhatascend.').';
        P_tilde=exp(-R_hat_s3); 
        W_tilde(:,m_tilde,n_frame)=P_tilde(:,1).*W_tilde(:,m_tilde,n_frame-1);
        W_tilde(:,m_tilde,n_frame)=W_tilde(:,m_tilde,n_frame)/sum(W_tilde(:,m_tilde,n_frame).');
        c_Wtilde(1)=W_tilde(1,m_tilde,n_frame);
        for index_particle=2:B1
            c_Wtilde(index_particle)=c_Wtilde(index_particle-1)+W_tilde(index_particle,m_tilde,n_frame);
        end
        %
        for index_particle=1:B1
            suijishu=rand;
            for index_particle1=1:B1
                if suijishu<c_Wtilde(index_particle1)
                    Y_tilde(1:2,index_particle,m_tilde,n_frame)=Y_hat(1:2,index_particle1,m_tilde,n_frame);
                    if n_frame>=3 && O(m_tilde,n_frame)==1 && O(m_tilde,n_frame-1)==1 && O(m_tilde,n_frame-2)==1
                        Y_tilde(3:4,index_particle,m_tilde,n_frame)=(Y_breve(3:4,m_tilde,n_frame-1)-Y_breve(3:4,m_tilde,n_frame-2))/periodicity;
                    end
                    break;
                end
            end
        end
        Y_breve(1:4,m_tilde,n_frame)=Y_tilde(1:4,:,m_tilde,n_frame)*W_tilde(:,m_tilde,n_frame);
        Y1_Rpoint=zeros(2,B1);
        for n_clusterpoint=1:B1
            Y1_Rpoint(1:4,n_clusterpoint)=abs(Y_tilde(1:4,n_clusterpoint,m_tilde,n_frame)-Y_breve(1:4,m_tilde,n_frame));
        end
        R_tilde(1:4,m_tilde,n_frame)=max(Y1_Rpoint,[],2);
        %
        [Z_bar,R_Z] = centerofmassandradius_X(Z,B_tilde,m_tilde,n_frame,Z_bar,R_Z);
        for index_particle=round(B1*0.5)+1:B1
            Y_tilde(1:2,index_particle,m_tilde,n_frame)=[(coefficient_RP(1)*R_Z(1,m_tilde,n_frame)+r2(1))*(2*rand-1);(coefficient_RP(2)*R_Z(2,m_tilde,n_frame)+r2(2))*(2*rand-1)]+Z_bar(1:2,m_tilde,n_frame);
        end
        %
        W_tilde(:,m_tilde,n_frame)=1/B1;
    elseif O(m_tilde,n_frame-1)==1 && O(m_tilde,n_frame)==-1
       %% 
        for index_particle=1:B1
            Y_tilde(1:2,index_particle,m_tilde,n_frame)=[(coefficient_RP(1)*R_Z(1,m_tilde,n_frame-1)+r2(1))*(2*rand-1);(coefficient_RP(2)*R_Z(2,m_tilde,n_frame-1)+r2(2))*(2*rand-1)]+Z_bar(1:2,m_tilde,n_frame-1);
        end
        W_tilde(:,m_tilde,n_frame)=1/B1;
        Y_breve(1:4,m_tilde,n_frame)=Y_tilde(1:4,:,m_tilde,n_frame)*W_tilde(:,m_tilde,n_frame);
        Y1_Rpoint=zeros(2,B1);
        for n_clusterpoint=1:B1
            Y1_Rpoint(1:4,n_clusterpoint)=abs(Y_tilde(1:4,n_clusterpoint,m_tilde,n_frame)-Y_breve(1:4,m_tilde,n_frame));
        end
        R_tilde(1:4,m_tilde,n_frame)=max(Y1_Rpoint,[],2);
    elseif O(m_tilde,n_frame-1)==-1 && O(m_tilde,n_frame)==1
        A_tilde=[1,0,periodicity,0;0,1,0,periodicity;0,0,1,0;0,0,0,1];
        Y_hat(1:4,1:B1,m_tilde,n_frame)=A_tilde*Y_tilde(1:4,1:B1,m_tilde,n_frame-1)+sqrtm(Noise_Q)*randn(4,B1);
        R_hat=[];value_Rhatascend=[];R_hat_s3=[];P_tilde=[];
        for index_particle=1:B1
            for index_point=1:size(cluster_data,1)
                R_hat(index_particle, index_point)=norm(Y_hat(1:2,index_particle,m_tilde,n_frame)-cluster_data(index_point,1:2).');
            end
        end
        [value_Rhatascend,index_Rhatascend]=sort(R_hat,2,'ascend');
        value_Rhatascend(1:B1,4:index_point)=0;
        R_hat_s3=sum(value_Rhatascend.').';
        P_tilde=exp(-R_hat_s3); 
        W_tilde(:,m_tilde,n_frame)=P_tilde(:,1).*W_tilde(:,m_tilde,n_frame-1);
        W_tilde(:,m_tilde,n_frame)=W_tilde(:,m_tilde,n_frame)/sum(W_tilde(:,m_tilde,n_frame).');
        c_Wtilde(1)=W_tilde(1,m_tilde,n_frame);
        for index_particle=2:B1
            c_Wtilde(index_particle)=c_Wtilde(index_particle-1)+W_tilde(index_particle,m_tilde,n_frame);
        end
        %
        for index_particle=1:B1
            suijishu=rand;
            for index_particle1=1:B1
                if suijishu<c_Wtilde(index_particle1)
                    Y_tilde(1:2,index_particle,m_tilde,n_frame)=Y_hat(1:2,index_particle1,m_tilde,n_frame);
                    if n_frame>=3 && O(m_tilde,n_frame)==1 && O(m_tilde,n_frame-1)==1 && O(m_tilde,n_frame-2)==1
                        Y_tilde(3:4,index_particle,m_tilde,n_frame)=(Y_breve(3:4,m_tilde,n_frame-1)-Y_breve(3:4,m_tilde,n_frame-2))/periodicity;
                    end
                    break;
                end
            end
        end
        Y_breve(1:4,m_tilde,n_frame)=Y_tilde(1:4,:,m_tilde,n_frame)*W_tilde(:,m_tilde,n_frame);
        Y1_Rpoint=zeros(2,B1);
        for n_clusterpoint=1:B1
            Y1_Rpoint(1:4,n_clusterpoint)=abs(Y_tilde(1:4,n_clusterpoint,m_tilde,n_frame)-Y_breve(1:4,m_tilde,n_frame));
        end
        R_tilde(1:4,m_tilde,n_frame)=max(Y1_Rpoint,[],2);
        %
        [Z_bar,R_Z] = centerofmassandradius_X(Z,B_tilde,m_tilde,n_frame,Z_bar,R_Z);
        for index_particle=round(B1*0.5)+1:B1
            Y_tilde(1:2,index_particle,m_tilde,n_frame)=[(coefficient_RP(1)*R_Z(1,m_tilde,n_frame)+r2(1))*(2*rand-1);(coefficient_RP(2)*R_Z(2,m_tilde,n_frame)+r2(1))*(2*rand-1)]+Z_bar(1:2,m_tilde,n_frame);
        end
        %
        W_tilde(:,m_tilde,n_frame)=1/B1;
    elseif O(m_tilde,n_frame-1)==-1 && O(m_tilde,n_frame)==-1
        index_O1=[];
        index_O1=find(O(m_tilde,n_startframe:n_frame-1)==1)+n_startframe-1;
        index_O11=max(index_O1);
        for index_particle=1:B1
            Y_tilde(1:2,index_particle,m_tilde,n_frame)=[(coefficient_RP(1)*R_Z(1,m_tilde,index_O11)+r2(1))*(2*rand-1);(coefficient_RP(2)*R_Z(2,m_tilde,index_O11)+r2(2))*(2*rand-1)]+Z_bar(1:2,m_tilde,index_O11);
        end
        W_tilde(:,m_tilde,n_frame)=1/B1;
        Y_breve(1:4,m_tilde,n_frame)=Y_tilde(1:4,:,m_tilde,n_frame)*W_tilde(:,m_tilde,n_frame);
        Y1_Rpoint=zeros(2,B1);
        for n_clusterpoint=1:B1
            Y1_Rpoint(1:4,n_clusterpoint)=abs(Y_tilde(1:4,n_clusterpoint,m_tilde,n_frame)-Y_breve(1:4,m_tilde,n_frame));
        end
        R_tilde(1:4,m_tilde,n_frame)=max(Y1_Rpoint,[],2);
    end
end
