%% Parameter setting
clc;
clear;
clear all;
close all;
c=3e8; 
fc=77e9; 
Frequency_Slope=62e12;
Sample_Rate=5000e3;
ADC_samples=256;
Num_chirp=255;
frame=180;
Num_Tantenna=2;
periodicity=67/(1e3);
Idletime=70e-6;
Rampendtime=60e-6;
deltaF=(ADC_samples/Sample_Rate)*Frequency_Slope;
T_sample=ADC_samples/Sample_Rate;
T_chirp=(Idletime+Rampendtime)*Num_Tantenna;
Oneframetime=T_chirp*Num_chirp;
lamuda = c/fc;
Range_resolution=c/(2*deltaF);
Doppler_resolution=lamuda/(2*Oneframetime);
Range_max=Sample_Rate*c/(2*Frequency_Slope);
dutycycle=Oneframetime/periodicity;
v_max=lamuda/(4*T_chirp);
T=periodicity/Num_chirp;
%%
location='D:\DFP-response-R3\Data\';name='2';dataname_Q='point cloud\';
ma=strcat(location,dataname_Q);
load(strcat(ma,name,'.mat'), 'Q');
N_range=512; N_doppler=512;
Range_resolution=Range_resolution*ADC_samples/N_range;
K=N_range;
K3=9;
Range_resolution_hat=Range_resolution/(K3+1);
K_hat=(K3+1)*K;
N_Theta=181;
AoA=linspace(-60,60,N_Theta).';
AoA_resolution=60*2/(N_Theta-1);
M1=20;
M_tilde=5;
M_breve=5;
B1=50;
B2=40;
B3=3;
B=zeros(M1,frame);
B_tilde=zeros(M_tilde+M_breve,frame);
O_tilde=zeros(M1,frame);
O=zeros(M_tilde+M_breve,frame);
X=zeros(2,B2,M1,frame);
Z=zeros(2,B2,M_tilde+M_breve,frame);
Y_tilde=zeros(4,B1,M_tilde+M_breve,frame);
Y_hat=zeros(4,B1,M_tilde+M_breve,frame);
Y_breve=zeros(4,M_tilde+M_breve,frame);
W_tilde=zeros(B1,M_tilde+M_breve,frame);
R_tilde=zeros(2,M_tilde+M_breve,frame);
X_bar=zeros(2,M1,frame);
R=zeros(2,M1,frame);
R_Z=zeros(2,M_tilde+M_breve,frame);
Z_bar=zeros(2,M_tilde+M_breve,frame);
coefficient_RP=[1;1];
r1=[10;0.7];
r2=[10;0.5];
b_T=2;
n_frame_T1=5;
n_frame_T2=3;
a=['.r' 'or' 'sr' '^r' 'xr' '+r' '*r' 'vr' 'dr'  '>r' '<r'  'pr'];
b=['.b' 'ob' 'sb' '^b' 'xb' '+b' '*b' 'vb' 'db'  '>b' '<b'  'pb'];
c=['.k' 'ok' 'sk' '^k' 'xk' '+k' '*k' 'vk' 'dk' '>k' '<k' 'pk'];
d=['.m' 'om' 'sm' '^m' 'xm' '+m' '*m' 'vm' 'dm' '>m' '<m' 'pm'];
e=['.c' 'oc' 'sc' '^c' 'xc' '+c' '*c' 'vc' 'dc' '>c' '<c' 'pc'];
epsilon=1.5;
MinPts= 2;
Noise_Q=1*10^(-3)*[1,0,0,0;0,1,0,0;0,0,0.01,0;0,0,0,0.01];
Noise_R=1*10^(-2)*[1 0;0 1];
n_startframe=1;
for n_frame=n_startframe:frame
    clear locsr locsa cluster_data index_clusterdata IDX1 lc cluster_num cluster_size cluster_data_1
    [locsa,locsr] = find(Q(:,:,n_frame));
    cluster_data(:,1)=AoA(locsa);cluster_data(:,2)=locsr*Range_resolution_hat;
    %% Initial time
    if n_frame==n_startframe
        M=0;
        IDX1=DBSCAN(cluster_data,epsilon,MinPts);
        cluster_num = unique(IDX1);
        lc = find(cluster_num == 0);
        cluster_num(lc) = [];
        for m_check = 1:length(cluster_num)
            lc = find(IDX1 == cluster_num(m_check));
            M=M+1;
            B(M,n_frame)=length (lc);
            X(1,1:B(M,n_frame),M,n_frame)=cluster_data(lc,1);
            X(2,1:B(M,n_frame),M,n_frame)=cluster_data(lc,2);
            O_tilde(M,n_frame)=1;
        end
    else
       %% Determine if existing targets still exists
        index_clusterdata=zeros(1,length(locsa));
        for m_tilde=1:M_tilde+M_breve
            if O(m_tilde,n_frame-1)==1
                [index_clusterdata,B_tilde]=findpoint(locsa,cluster_data,Y_breve,m_tilde,n_frame,R_tilde,r2,index_clusterdata,B_tilde);
                if B_tilde(m_tilde,n_frame)>=b_T
                    O(m_tilde,n_frame)=1;n_B=1;
                    for n_point = 1:length(locsa)
                        if index_clusterdata(1,n_point)==m_tilde
                            Z(1,n_B,m_tilde,n_frame)=cluster_data(n_point,1);
                            Z(2,n_B,m_tilde,n_frame)=cluster_data(n_point,2);
                            index_clusterdata(1,n_point)=100;
                            n_B=n_B+1;
                        end
                    end                    
                    [W_tilde,Y_tilde,Y_breve,R_tilde,R_Z,Z_bar] = particlefilter_subfile(M_tilde,M_breve,m_tilde,coefficient_RP,r2,B1,W_tilde,Y_tilde,Y_breve,R_tilde,O,Z,B_tilde,Noise_Q,R_Z,Z_bar,X,B,m,n_startframe,n_frame,X_bar,R,cluster_data,Range_resolution,N_range,N_Theta,AoA,periodicity);
                else
                    O(m_tilde,n_frame)=-1;
                    [W_tilde,Y_tilde,Y_breve,R_tilde,R_Z,Z_bar] = particlefilter_subfile(M_tilde,M_breve,m_tilde,coefficient_RP,r2,B1,W_tilde,Y_tilde,Y_breve,R_tilde,O,Z,B_tilde,Noise_Q,R_Z,Z_bar,X,B,m,n_startframe,n_frame,X_bar,R,cluster_data,Range_resolution,N_range,N_Theta,AoA,periodicity);                    
                end
            elseif O(m_tilde,n_frame-1)==-1 
                index_O1=[];
                index_O1=find(O(m_tilde,n_startframe:n_frame-1)==1)+n_startframe-1;
                index_O11=max(index_O1);
                if n_frame-index_O11<n_frame_T1
                    [index_clusterdata,B_tilde]=findpoint(locsa,cluster_data,Y_breve,m_tilde,n_frame,R_tilde,r2,index_clusterdata,B_tilde);
                    if B_tilde(m_tilde,n_frame)>=b_T
                        O(m_tilde,n_frame)=1;n_B=1;
                        for n_point = 1:length(locsa)
                            if index_clusterdata(1,n_point)==m_tilde
                                Z(1,n_B,m_tilde,n_frame)=cluster_data(n_point,1);
                                Z(2,n_B,m_tilde,n_frame)=cluster_data(n_point,2);
                                index_clusterdata(1,n_point)=100;
                                n_B=n_B+1;
                            end
                        end
                        [W_tilde,Y_tilde,Y_breve,R_tilde,R_Z,Z_bar] = particlefilter_subfile(M_tilde,M_breve,m_tilde,coefficient_RP,r2,B1,W_tilde,Y_tilde,Y_breve,R_tilde,O,Z,B_tilde,Noise_Q,R_Z,Z_bar,X,B,m,n_startframe,n_frame,X_bar,R,cluster_data,Range_resolution,N_range,N_Theta,AoA,periodicity);
                    else
                        O(m_tilde,n_frame)=-1;
                        [W_tilde,Y_tilde,Y_breve,R_tilde,R_Z,Z_bar] = particlefilter_subfile(M_tilde,M_breve,m_tilde,coefficient_RP,r2,B1,W_tilde,Y_tilde,Y_breve,R_tilde,O,Z,B_tilde,Noise_Q,R_Z,Z_bar,X,B,m,n_startframe,n_frame,X_bar,R,cluster_data,Range_resolution,N_range,N_Theta,AoA,periodicity);
                    end
                else
                    O(m_tilde,n_frame)=0;
                end               
            end
        end
       %% Determine whether the existing cloud clusters still exists
        for m=1:M
            if O_tilde(m,n_frame-1)==1
                [X_bar,R] = centerofmassandradius_X(X,B,m,n_frame-1,X_bar,R);
                [index_clusterdata,B]=findpoint(locsa,cluster_data,X_bar,m,n_frame,R,r1,index_clusterdata,B);
                if B(m,n_frame)>=b_T
                    O_tilde(m,n_frame)=1;n_B=1;
                    for n_point = 1:length(locsa)
                        if index_clusterdata(1,n_point)==m
                            X(1,n_B,m,n_frame)=cluster_data(n_point,1);
                            X(2,n_B,m,n_frame)=cluster_data(n_point,2);
                            index_clusterdata(1,n_point)=100;
                            n_B=n_B+1;
                        end
                    end
                  %% Determine whether a point cloud cluster is a target
                    if n_frame>=n_frame_T2 && sum(O_tilde(m,n_frame-n_frame_T2+1:n_frame))==n_frame_T2
                        for m_breve=M_tilde+1:M_tilde+M_breve
                            if O(m_breve,n_frame)==0
                                O(m_breve,n_frame)=1;
                                break;
                            end
                        end
                        O_tilde(m,n_frame)=0;
                        [W_tilde,Y_tilde,Y_breve,R_tilde] = particlefilter_subfile(M_tilde,M_breve,m_breve,coefficient_RP,r2,B1,W_tilde,Y_tilde,Y_breve,R_tilde,O,Z,B_tilde,Noise_Q,R_Z,Z_bar,X,B,m,n_startframe,n_frame,X_bar,R,cluster_data,Range_resolution,N_range,N_Theta,AoA,periodicity);
                    end
                else
                    O_tilde(m,n_frame)=-1;%Not sure whether really leave, follow-up to continue to evaluate
                end
            end
        end
       %% Determine whether the remaining points can form a point cloud cluster
        n_B=0;
        for n_point = 1:length(locsa)
            if index_clusterdata(1,n_point)==0
                n_B=n_B+1;
                cluster_data_1(n_B,1)=cluster_data(n_point,1);
                cluster_data_1(n_B,2)=cluster_data(n_point,2);
                index_clusterdata(1,n_point)=100;
            end
        end
        if n_B>=MinPts
            IDX1=DBSCAN(cluster_data_1,epsilon,MinPts);
            cluster_num = unique(IDX1);
            lc = find(cluster_num == 0);
            cluster_num(lc) = [];
            m=0;m_check=1;M_check=length(cluster_num);
            while M_check >=1&&m_check<=M_check
                lc = find(IDX1 == cluster_num(m_check));
                m=m+1;
                index1_n_frame=0;
                for m_n_frame=1:n_frame
                    if O_tilde(m,m_n_frame)==-1
                        index1_n_frame=m_n_frame;
                    end
                end
                if index1_n_frame>0
                    index1_n_frame=index1_n_frame-1;
                    if m<=M && O_tilde(m,n_frame)==0 && n_frame-index1_n_frame<=n_frame_T1 
                        Amax_cluster=max(cluster_data_1(:,1));
                        Amin_cluster=min(cluster_data_1(:,1));
                        Rmax_cluster=max(cluster_data_1(:,2));
                        Rmin_cluster=min(cluster_data_1(:,2));
                        AoA_R=min(abs(Amax_cluster-X_bar(1,m,index1_n_frame)), abs(Amin_cluster-X_bar(1,m,index1_n_frame)));
                        Range_R=min(abs(Rmax_cluster-X_bar(2,m,index1_n_frame)),abs(Rmin_cluster-X_bar(2,m,index1_n_frame)));
                        if AoA_R<R(1,m,index1_n_frame)+r1(1)*(n_frame-index1_n_frame) && Range_R<R(2,m,index1_n_frame)+r1(2)*(n_frame-index1_n_frame)
                            B(m,n_frame)=length (lc);
                            X(1,1:B(m,n_frame),m,n_frame)=cluster_data_1(lc,1);
                            X(2,1:B(m,n_frame),m,n_frame)=cluster_data_1(lc,2);
                            O_tilde(m,index1_n_frame:n_frame)=1;m_check=m_check+1;
                        end
                    elseif m<=M && O_tilde(m,n_frame)==0 && n_frame-index1_n_frame>n_frame_T1
                        B(m,n_frame)=length (lc);
                        X(1,1:B(m,n_frame),m,n_frame)=cluster_data_1(lc,1);
                        X(2,1:B(m,n_frame),m,n_frame)=cluster_data_1(lc,2);
                        O_tilde(m,n_frame)=1;m_check=m_check+1;
                    end
                elseif m>M || O_tilde(m,n_frame)==0
                    B(m,n_frame)=length (lc);
                    X(1,1:B(m,n_frame),m,n_frame)=cluster_data_1(lc,1);
                    X(2,1:B(m,n_frame),m,n_frame)=cluster_data_1(lc,2);
                    O_tilde(m,n_frame)=1;m_check=m_check+1;
                    M=max(m,M);
                end
            end                
        end
    end
end
n_frame1=n_frame;
figure; 
for n_frame=n_startframe:n_frame1
    for m_tilde=1:M_tilde+M_breve
        if O(m_tilde,n_frame)==1 || O(m_tilde,n_frame)==-1
            plot(Y_breve(1,m_tilde,n_frame),Y_breve(2,m_tilde,n_frame),b(1, (m_tilde-1)*2+1:m_tilde*2));hold on
            ylim([1*Range_resolution,N_range*Range_resolution]);
            xlim([AoA(1), AoA(N_Theta)]);
            set(gca,'FontName','Times New Roman','fontsize',13)
            title('RAM', 'fontsize', 20);
            xlabel('AoA/degree', 'fontsize', 20);
            ylabel('Range/m', 'fontsize', 20);
        end
    end
end

% dataname_Q='tracking\';file_name='Y_breve\'; %Particle cluster centroid
% ma=strcat(location,dataname_Q,file_name);mkdir(ma);
% save(strcat(ma,name,'.mat'), 'Y_breve');
% 
% dataname_Q='tracking\';file_name='O\'; %Targets state
% ma=strcat(location,dataname_Q,file_name);mkdir(ma);
% save(strcat(ma,name,'.mat'), 'O');
% 
% dataname_Q='tracking\';file_name='R_tilde\'; %Radius of particle cluster
% ma=strcat(location,dataname_Q,file_name);mkdir(ma);
% save(strcat(ma,name,'.mat'), 'R_tilde');