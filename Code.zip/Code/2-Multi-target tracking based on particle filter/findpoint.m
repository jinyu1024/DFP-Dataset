function [index_clusterdata,B_tilde]=findpoint(locsa,cluster_data,Y_breve,m_tilde,n_frame,R_tilde,r2,index_clusterdata,B_tilde)
    for n_point = 1:length(locsa)
        if abs(cluster_data(n_point,1)-Y_breve(1,m_tilde,n_frame-1))<R_tilde(1,m_tilde,n_frame-1)+r2(1) && abs(cluster_data(n_point,2)-Y_breve(2,m_tilde,n_frame-1))<R_tilde(2,m_tilde,n_frame-1)+r2(2)
            if index_clusterdata(1,n_point)==0
                B_tilde(m_tilde,n_frame)=B_tilde(m_tilde,n_frame)+1;
                index_clusterdata(1,n_point)=m_tilde;
            elseif index_clusterdata(1,n_point)~=0 && index_clusterdata(1,n_point)~=100
                AoA_findpast=abs(cluster_data(n_point,1)-Y_breve(1,index_clusterdata(1,n_point),n_frame-1));
                Range_findpast=abs(cluster_data(n_point,2)-Y_breve(2,index_clusterdata(1,n_point),n_frame-1));
                AoA_find=abs(cluster_data(n_point,1)-Y_breve(1,m_tilde,n_frame-1));
                Range_find=abs(cluster_data(n_point,2)-Y_breve(2,m_tilde,n_frame-1));
                if AoA_find<AoA_findpast || Range_find<Range_findpast
                    B_tilde(m_tilde,n_frame)=B_tilde(m_tilde,n_frame)+1;
                    index_clusterdata(1,n_point)=m_tilde;
                end
            end
        end
    end
end