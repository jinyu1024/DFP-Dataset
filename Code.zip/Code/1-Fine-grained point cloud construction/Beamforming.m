function [S,Power]=Beamforming(A, nTx, Angle)
[~,K]=size(A);
Rxx=A*A'/K;
for i=1:nTx
    ad(i,1)=exp(1i*(i-1)*pi*sin(pi/180*(Angle)));
end
w=inv(Rxx)*ad/(ad'*inv(Rxx)*ad);
S=w'*A;
for n_rangebin=1:K
    Power(1,n_rangebin)=abs(S(1,n_rangebin))^2;
end