function [retVal] = readDCA1000(fileName,ADC_sample,Num_Tantenna)
numADCBits = 16; 
numLanes = 4; 
isReal = 0; 

fid = fopen(fileName,'r'); 
% DCA1000 should read in two's complement data
adcData = fread(fid, 'int16'); % set to 1 if real only data, 0 if complex dataare populated with 0 %% read file and convert to signed number
% if 12 or 14 bits ADC per sample compensate for sign extension
if numADCBits ~= 16 
    l_max = 2^(numADCBits-1)-1; 
    adcData(adcData > l_max) = adcData(adcData > l_max) - 2^numADCBits; 
end
fclose(fid);
%% organize data by LVDS lane
% for real only data
if isReal 
% reshape data based on one samples per LVDS lane
    adcData = reshape(adcData, numLanes, []); 
%for complex data   
else
% reshape and combine real and imaginary parts of complex number
    adcData = reshape(adcData, numLanes*2, []);
    adcData = adcData([1,2,3,4],:) + sqrt(-1)*adcData([5,6,7,8],:);
end
[m,n]=size(adcData);
multiantennaData=zeros(m*Num_Tantenna,n/Num_Tantenna);
if Num_Tantenna==1
    multiantennaData=adcData;
elseif Num_Tantenna==2
    for i=1:n/(Num_Tantenna*ADC_sample)
        multiantennaData(1:4,ADC_sample*(i-1)+(1:ADC_sample))=adcData(:,ADC_sample*(Num_Tantenna*(i-1)+0)+(1:ADC_sample));
        multiantennaData(5:8,ADC_sample*(i-1)+(1:ADC_sample))=adcData(:,ADC_sample*(Num_Tantenna*(i-1)+1)+(1:ADC_sample));
    end            
elseif Num_Tantenna==3
    for i=1:n/(Num_Tantenna*ADC_sample)
        multiantennaData(1:4,ADC_sample*(i-1)+(1:ADC_sample))=adcData(:,ADC_sample*(Num_Tantenna*(i-1)+0)+(1:ADC_sample));
        multiantennaData(5:8,ADC_sample*(i-1)+(1:ADC_sample))=adcData(:,ADC_sample*(Num_Tantenna*(i-1)+1)+(1:ADC_sample));
        multiantennaData(9:12,ADC_sample*(i-1)+(1:ADC_sample))=adcData(:,ADC_sample*(Num_Tantenna*(i-1)+2)+(1:ADC_sample));
    end
end
%% return receiver data
retVal = multiantennaData;      
