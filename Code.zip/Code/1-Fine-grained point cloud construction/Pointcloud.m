%% Parameter setting
clc;
clear;
clear all;
close all;
c=3e8; 
fc=77e9; 
Frequency_Slope=62e12;
Sample_Rate=5000e3;
ADC_samples=256;
Num_chirp=255;
frame=180;
Num_Tantenna=2;
periodicity=67/(1e3);
Idletime=70e-6;
Rampendtime=60e-6;
deltaF=(ADC_samples/Sample_Rate)*Frequency_Slope;
T_sample=ADC_samples/Sample_Rate;
T_chirp=(Idletime+Rampendtime)*Num_Tantenna;
Oneframetime=T_chirp*Num_chirp;
lamuda = c/fc;
Range_resolution=c/(2*deltaF);
Doppler_resolution=lamuda/(2*Oneframetime);
Range_max=Sample_Rate*c/(2*Frequency_Slope);
dutycycle=Oneframetime/periodicity;
v_max=lamuda/(4*T_chirp);
T=periodicity/Num_chirp;
%%
location='D:\DFP-response-R3\Data\';dataname_raw='0-raw data\';name='2';
filenames=strcat(location,dataname_raw,name,'.bin');
for filelen=1:length(filenames)
    A=readDCA1000(filenames,ADC_samples,Num_Tantenna);
end
dataname_A='A\';
ma=strcat(location,dataname_A);mkdir(ma);
save(strcat(ma,name,'.mat'), 'A');
%%%%%%%%%OR%%%%%%%%%%
% dataname_A='A\';
% ma=strcat(location,dataname_A);
% load(strcat(ma,name,'.mat'), 'A');
%%
N_range=512; N_doppler=512;
Range_resolution=Range_resolution*ADC_samples/N_range;
K=N_range;
K3=9;
Range_resolution_hat=Range_resolution/(K3+1);
K_hat=(K3+1)*K;
N_Theta=181;
Q(1:N_Theta,1:K_hat,frame)=0;
AoA=linspace(-60,60,N_Theta);
AoA_resolution=60*2/(N_Theta-1);
D = 1;
for n_frame=1:1:frame-D+1
    clear locsr locsa col maxe_T
    for channel=1:8
        A_frame=A(channel,(n_frame-1)*ADC_samples*Num_chirp+1:(n_frame+D-1)*ADC_samples*Num_chirp);
        Rawdata=reshape(A_frame,ADC_samples,[]);
        [M1,M1_abs]=Rangefft(Rawdata,N_range,Range_resolution,T,D,n_frame,periodicity);
        M1_1(channel,:,:)=M1(:,:);
    end
    %% AoA
    H=M1_1(:,:,1);nTx=8;
    for n_theta=1:N_Theta
        theta=(n_theta-1)*AoA_resolution-60;
        [H1,Power]=Beamforming(H, nTx, theta);
        M2_1(:,n_theta)=Power;
    end
    M2_h=abs(M2_1);
    n_1=size(M2_h,1); 
    m_1=size(M2_h,2);
    Range=linspace(1,n_1,n_1);

    maxe_col=max(M2_h,[],2);
    [maxe_row,maxe_rowindex]=max(maxe_col,[],1);
   
    indexyueshu=20;ez1=1.7;ez2=ez1+0.02;ej=maxe_row/800;
    if maxe_rowindex>indexyueshu
        maxe_T(1:maxe_rowindex-indexyueshu,1)=maxe_row/ez2;
        if N_range-maxe_rowindex>indexyueshu
            maxe_T(maxe_rowindex-indexyueshu:maxe_rowindex+indexyueshu,1)=maxe_row/ez1;
            maxe_T(maxe_rowindex+indexyueshu+1:N_range,1)=maxe_row/ez1:-ej:maxe_row/ez1-ej*(N_range-(maxe_rowindex+indexyueshu+1));
        end
    else
        maxe_T(1:maxe_rowindex+indexyueshu,1)=maxe_row/ez1;
        maxe_T(maxe_rowindex+indexyueshu+1:N_range,1)=maxe_row/ez1:-ej:maxe_row/ez1-ej*(N_range-(maxe_rowindex+indexyueshu+1));
    end
    
    M2_e=M2_h;
    for nh=1:n_1
        for ml=1:m_1
            if M2_e(nh,ml)<maxe_T(nh,1)
                M2_e(nh,ml)=0;
            end
        end
    end
    %% Location visualization
    [locsr,locsa] = find(M2_e);
%     figure;
%     plot(AoA(locsa),locsr*Range_resolution,'.b');
%     ylim([1*Range_resolution,N_range*Range_resolution]);
%     xlim([-60,60]);
%     set(gca,'FontName','Times New Roman','fontsize',13)
%     title('RAM', 'fontsize', 20);%Relative position
%     xlabel('AoA/degree', 'fontsize', 20);
%     ylabel('Range/m', 'fontsize', 20);    
    %% Find targets at each AoA
    for n_theta=1:N_Theta
        K1=10;%Hop size of the range window
        K2=30;%Length of the range window
        J=(N_range-K2)/K1+1; %Index number of range window
        for j=1:J
            k1=1+(j-1)*K1;
            k2=K2+(j-1)*K1;
            V(1,j)=var(M2_e(k1:k2,n_theta));
        end
        [row,col]=find (V>0);
        if size(col,2)>0
          %% Find the range index of targets
            v1=col(1);v2=col(1);
            n_loc=1;
            if size(col,2)==1
                [max_e,index]=max(M2_e(1+(v1-1)*K1:K2+(v2-1)*K1,n_theta),[],1);
                k_loc(n_loc)=(v1-1)*K1+index;
            elseif size(col,2)>=2                                    
                for n_fangcha=2:size(col,2)
                    if col(n_fangcha)==v2+1;
                        v2=col(n_fangcha);
                        if n_fangcha==size(col,2)
                            [max_e,index]=max(M2_e(1+(v1-1)*K1:K2+(v2-1)*K1,n_theta),[],1);
                            k_loc(n_loc)=(v1-1)*K1+index;
                        end
                    else
                        [max_e,index]=max(M2_e(1+(v1-1)*K1:K2+(v2-1)*K1,n_theta),[],1);
                        k_loc(n_loc)=(v1-1)*K1+index;
                        n_loc=n_loc+1;
                        v1=col(n_fangcha);v2=col(n_fangcha);    
                        if n_fangcha==size(col,2)
                            [max_e,index]=max(M2_e(1+(v1-1)*K1:K2+(v2-1)*K1,n_theta),[],1);
                            k_loc(n_loc)=(v1-1)*K1+index;
                        end
                    end  
                end
            end
          %%
            n_fitcishu=2;n_fitdianshu=3;
            for n_tloc=1:n_loc
                x=k_loc(n_tloc)-1:k_loc(n_tloc)+1;
                y=M2_h(k_loc(n_tloc)-1:k_loc(n_tloc)+1,n_theta).';
                a=polyfit(x,y,n_fitcishu);
                x_hat=k_loc(n_tloc)-1:1/(K3+1) : k_loc(n_tloc)+1;
                for k_hat_loc1=1:n_fitdianshu+(n_fitdianshu-1)*K3
                    y_fit(1,k_hat_loc1)=0;
                    for j=1:n_fitcishu+1
                        y_fit(1,k_hat_loc1)=y_fit(1,k_hat_loc1)+a(j)*x_hat(k_hat_loc1)^(3-j);
                    end
                end
                [max_e,index]=max(y_fit);
                k_hat_loc(n_tloc)=(K3+1)*(k_loc(n_tloc)-1)-1+index;
              %% save point cloud
                Q(n_theta,k_hat_loc(n_tloc),n_frame)=1;
            end
        end
    end
end
dataname_Q='point cloud\';
ma=strcat(location,dataname_Q);mkdir(ma);
save(strcat(ma,name,'.mat'), 'Q');