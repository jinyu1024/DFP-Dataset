function [y2A]=curvefitting(x,y,Nue)
for i=1:Nue
    y2=polyfit(x,y,i);
    Y=polyval(y2,x);
    dif(1,i)=sum((Y-y).^2);
end
[M,Nuem] = min(dif);

NA=Nuem;
y1A=polyfit(x,y,NA);
for i=1:size(x,2)
    y2A(1,i)=0;
    for j=1:NA+1
        y2A(1,i)=y2A(1,i)+y1A(j)*x(1,i)^(NA+1-j);
    end
end
