function [v_norm,locs,loc_min,amplitude,y_mean]=normalization(Time,v_actual,Num_v,T)
x=Time;
y=v_actual;
y_mean=mean(y,2);

for n_max=3:20
    [xpeak,locs] = findpeak(x,y,0,0.3/T,n_max);
    pd_locs=isnan(locs); 
    if pd_locs(1,n_max)~=0
        break;
    end   
end
n_max1=n_max-1;
[xpeak,locs] = findpeak(x,y,0,0.3/T,n_max1);

locs=sort(locs);
v_actual_m(1,1:size(y,2))=y_mean;

% 
for i=1:n_max1+1
    if i==1
        qj_max(i)=max(y(1:locs(i)));
        qj_min(i)=min(y(1:locs(i)));
        loc_max(i)=find(y(1:locs(i))==qj_max(i));
        loc_min(i)=find(y(1:locs(i))==qj_min(i));
    elseif i>1 && i<n_max1+1
        qj_max(i)=max(y(locs(i-1):locs(i)));
        qj_min(i)=min(y(locs(i-1):locs(i)));
        loc_max(i)=find(y(locs(i-1):locs(i))==qj_max(i))+locs(i-1)-1;
        loc_min(i)=find(y(locs(i-1):locs(i))==qj_min(i))+locs(i-1)-1;
    else
        qj_max(i)=max(y(locs(i-1):Num_v));
        qj_min(i)=min(y(locs(i-1):Num_v));
        loc_max(i)=find(y(locs(i-1):Num_v)==qj_max(i))+locs(i-1)-1;
        loc_min(i)=find(y(locs(i-1):Num_v)==qj_min(i))+locs(i-1)-1;
    end
    fengexian(i,1:size(y,2))=x(loc_min(i));
end
ys=linspace(y_mean-0.2,y_mean+0.2,Num_v);

j=1;
loc_min1(1)=loc_min(1);
for k1=1:size(locs,2)
    if locs(k1)-loc_min(k1)>5 && loc_min(k1+1)-locs(k1)>5
            locs1(j)=locs(k1);
            loc_min1(j+1)=loc_min(k1+1);
            j=j+1;
    end
end
locs=locs1;
loc_min=loc_min1;
for k1=1:size(locs,2)
    fengexian1(k1,1:size(y,2))=loc_min(k1);
end
fengexian=fengexian1;

%
b=v_actual(locs)-v_actual_m(locs);
d=v_actual_m(loc_min)-v_actual(loc_min);
amplitude=(sum(b,2)+sum(d,2))/(size(locs,2)+size(loc_min,2));
ymax=y_mean+amplitude;
ymin=y_mean-amplitude;
%
for i=1:size(locs,2)
    if i==1
        if loc_min(i)==1
            xmin(i)=min(y(loc_min(i):locs(i)));
            xmax(i)=max(y(loc_min(i):locs(i)));
            y1=v_actual(1:locs(i));
            y2(1:locs(i))=(ymax-ymin)*(y1-xmin(i))/(xmax(i)-xmin(i))+ymin;
        
            xmin(i)=min(y(locs(i):locs(i+1)));
            xmax(i)=max(y(locs(i):loc_min(i+1)));
            y1=v_actual(locs(i):loc_min(i+1));
            y2(locs(i):loc_min(i+1))=(ymax-ymin)*(y1-xmin(i))/(xmax(i)-xmin(i))+ymin;
        else
            xmin(i)=min(y(1:loc_min(i)));
            xmax(i)=max(y(1:loc_min(i)));        
            y1=v_actual(1:loc_min(i));
            y2(1:loc_min(i))=(ymax-ymin)*(y1-xmin(i))/(xmax(i)-xmin(i))+ymin;
            
            xmin(i)=min(y(loc_min(i):locs(i)));
            xmax(i)=max(y(loc_min(i):locs(i)));
            y1=v_actual(loc_min(i):locs(i));
            y2(loc_min(i):locs(i))=(ymax-ymin)*(y1-xmin(i))/(xmax(i)-xmin(i))+ymin;
        
            xmin(i)=min(y(locs(i):locs(i+1)));
            xmax(i)=max(y(locs(i):loc_min(i+1)));
            y1=v_actual(locs(i):loc_min(i+1));
            y2(locs(i):loc_min(i+1))=(ymax-ymin)*(y1-xmin(i))/(xmax(i)-xmin(i))+ymin;
        end
    elseif i>1 && i<size(locs,2)-1
        xmin(i)=min(y(locs(i-1):locs(i)));
        xmax(i)=max(y(loc_min(i):locs(i)));
        y1=v_actual(loc_min(i):locs(i));
        y2(loc_min(i):locs(i))=(ymax-ymin).*(y1(1,:)-xmin(i))./(xmax(i)-xmin(i))+ymin;
        
        xmin(i)=min(y(locs(i):locs(i+1)));
        xmax(i)=max(y(locs(i):loc_min(i+1)));
        y1=v_actual(locs(i):loc_min(i+1));
        y2(locs(i):loc_min(i+1))=(ymax-ymin).*(y1(1,:)-xmin(i))./(xmax(i)-xmin(i))+ymin;
    else
        xmin(i)=min(y(locs(i-1):locs(i)));
        xmax(i)=max(y(loc_min(i):locs(i)));
        y1=v_actual(loc_min(i):locs(i));
        y2(loc_min(i):locs(i))=(ymax-ymin).*(y1(1,:)-xmin(i))./(xmax(i)-xmin(i))+ymin;
        
        xmin(i)=min(y(locs(i):loc_min(i+1)));
        xmax(i)=max(y(locs(i):loc_min(i+1)));
        y1=v_actual(locs(i):loc_min(i+1));
        y2(locs(i):loc_min(i+1))=(ymax-ymin).*(y1(1,:)-xmin(i))./(xmax(i)-xmin(i))+ymin;
        
        xmin(i)=min(y(loc_min(i+1):Num_v));
        xmax(i)=max(y(loc_min(i+1):Num_v));
        y1=v_actual(loc_min(i+1):Num_v);
        y2(loc_min(i+1):Num_v)=(ymax-ymin)*(y1-xmin(i))/(xmax(i)-xmin(i))+ymin;
    end  
end
v_norm=y2;