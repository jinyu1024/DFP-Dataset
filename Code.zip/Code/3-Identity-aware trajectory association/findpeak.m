function [xpeak,locs] = findpeak(x,y,threshold,peakdistance,npeaks)
locs = NaN*ones(1,npeaks);
markPeaks = dif(sign(dif(y)));
N = length(x);
for i = 1:N
    if y(i) <= threshold;
       y(i) = NaN;
    end
end
Peak = threshold;
locs(1) = 1;
for i = 2:N
    if (y(i) > Peak) && (markPeaks(i-1)==-2)
       Peak = y(i);
       locs(1) = i;
    end
end
M = floor(peakdistance/abs((x(2)- x(1))));
for i = 1:npeaks-1
    
    if (locs(i)-M>=1) && (locs(i)+M<=N) 
        y(locs(i)-M:locs(i)+M) = NaN;
    elseif (locs(i)-M < 1) && (locs(i)+M<=N)
        y(1:locs(i)+M) = NaN;
    elseif (locs(i)+M > N) && (locs(i)-M>=1)
        y(locs(i)-M:N) = NaN;
    else
        y(1:N) = NaN;
    end
    
    Peak = threshold;
    locs(i+1) = NaN;
    for j = 2:N
        if (y(j) > Peak) && (markPeaks(j-1)==-2)
           Peak = y(j);
           locs(i+1) = j;
        end
    end 
end

%% 
K = npeaks;
xpeak = NaN*ones(K,1);
for i = 1:K
    if isnan((locs(i)))
       continue;
    else
        xpeak(i) = x(locs(i));
    end
end
    
%% 
function dy = dif(y)
dy = zeros(size(y));
dy(1:end-1) = y(2:end) - y(1:end-1);
dy(end) = (y(end-2) + 2*y(end-1)- 3*y(end))/6;
