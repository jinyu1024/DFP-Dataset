%% Parameter setting
clc;
clear;
clear all;
close all;
c=3e8; 
fc=77e9; 
Frequency_Slope=62e12;
Sample_Rate=5000e3;
ADC_samples=256;
Num_chirp=255;
frame=180;
Num_Tantenna=2;
periodicity=67/(1e3);
Idletime=70e-6;
Rampendtime=60e-6;
deltaF=(ADC_samples/Sample_Rate)*Frequency_Slope;
T_sample=ADC_samples/Sample_Rate;
T_chirp=(Idletime+Rampendtime)*Num_Tantenna;
Oneframetime=T_chirp*Num_chirp;
lamuda = c/fc;
Range_resolution=c/(2*deltaF);
Doppler_resolution=lamuda/(2*Oneframetime);
Range_max=Sample_Rate*c/(2*Frequency_Slope);
dutycycle=Oneframetime/periodicity;
v_max=lamuda/(4*T_chirp);
T=periodicity/Num_chirp;
%%
location='D:\DFP-response-R3\Data\';name='2';dataname_Q='point cloud\';
ma=strcat(location,dataname_Q);
load(strcat(ma,name,'.mat'), 'Q');
N_range=512; N_doppler=512;
Range_resolution=Range_resolution*ADC_samples/N_range;
Doppler_resolution=Doppler_resolution*Num_chirp/N_doppler;
K=N_range;
K3=9;
Range_resolution_hat=Range_resolution/(K3+1);
K_hat=(K3+1)*K;
N_Theta=181;
AoA=linspace(-60,60,N_Theta).';
AoA_resolution=60*2/(N_Theta-1);
M1=20;
M_tilde=5;
M_breve=5;
B1=50;
B2=40;
B3=3;
B=zeros(M1,frame);
B_tilde=zeros(M_tilde+M_breve,frame);
O_tilde=zeros(M1,frame);
O=zeros(M_tilde+M_breve,frame);
X=zeros(2,B2,M1,frame);
Z=zeros(2,B2,M_tilde+M_breve,frame);
Y_tilde=zeros(4,B1,M_tilde+M_breve,frame);
Y_hat=zeros(4,B1,M_tilde+M_breve,frame);
Y_breve=zeros(4,M_tilde+M_breve,frame);
W_tilde=zeros(B1,M_tilde+M_breve,frame);
R_tilde=zeros(4,M_tilde+M_breve,frame);
X_bar=zeros(2,M1,frame);
R=zeros(2,M1,frame);
R_Z=zeros(2,M_tilde+M_breve,frame);
Z_bar=zeros(2,M_tilde+M_breve,frame);
coefficient_RP=[1;1];
r1=[10;0.7];
r2=[10;0.5];
b_T=2;
n_frame_T1=5;
n_frame_T2=3;
a=['.r' 'or' 'sr' '^r' 'xr' '+r' '*r' 'vr' 'dr'  '>r' '<r'  'pr'];
b=['.b' 'ob' 'sb' '^b' 'xb' '+b' '*b' 'vb' 'db'  '>b' '<b'  'pb'];
c=['.k' 'ok' 'sk' '^k' 'xk' '+k' '*k' 'vk' 'dk' '>k' '<k' 'pk'];
d=['.m' 'om' 'sm' '^m' 'xm' '+m' '*m' 'vm' 'dm' '>m' '<m' 'pm'];
e=['.c' 'oc' 'sc' '^c' 'xc' '+c' '*c' 'vc' 'dc' '>c' '<c' 'pc'];
epsilon=1.5;
MinPts= 2;
Noise_Q=1*10^(-3)*[1,0,0,0;0,1,0,0;0,0,0.01,0;0,0,0,0.01];
Noise_R=1*10^(-2)*[1 0;0 1];
L_frame=30;
m_tilde_Identity=zeros(1,M_tilde+M_breve);
m_tilde_Identity(1,1:M_tilde)=1;
U_tilde=zeros(3,M_tilde+M_breve,10);
J_hat=zeros(1,M_tilde+M_breve);
Q_tilde=zeros(M_tilde+M_breve,M_tilde+M_breve,frame);
R_bar_U_T=[0.2,0.1,0.05];
M_tilde_noid=1;
l_nframe=zeros(M_tilde+M_breve,1);
L_jiaohuframe=10;

dataname_Q='tracking\';file_name='Y_breve\';
ma=strcat(location,dataname_Q,file_name);
load(strcat(ma,name,'.mat'), 'Y_breve');
dataname_Q='tracking\';file_name='O\';
ma=strcat(location,dataname_Q,file_name);
load(strcat(ma,name,'.mat'), 'O');
dataname_Q='tracking\';file_name='R_tilde\';
ma=strcat(location,dataname_Q,file_name);
load(strcat(ma,name,'.mat'), 'R_tilde');
dataname_A='A\';
ma=strcat(location,dataname_A);
load(strcat(ma,name,'.mat'), 'A');

n_startframe=1;
n_frame1=180;
figure; 
for n_frame=n_startframe:n_frame1
    for m_tilde=1:M_tilde+M_breve
        if O(m_tilde,n_frame)==1 || O(m_tilde,n_frame)==-1
            plot(Y_breve(1,m_tilde,n_frame),Y_breve(2,m_tilde,n_frame),b(1, (m_tilde-1)*2+1:m_tilde*2));hold on
            ylim([1*Range_resolution,N_range*Range_resolution]);
            xlim([AoA(1), AoA(N_Theta)]);
            set(gca,'FontName','Times New Roman','fontsize',13)
            title('RAM', 'fontsize', 20);
            xlabel('AoA (degree)', 'fontsize', 20);
            ylabel('Range (m)', 'fontsize', 20);
        end
    end
end
%% Identity tracking
D=1;
for n_frame=n_startframe:n_frame1
    for m_tilde=M_tilde+1:M_tilde+M_breve
       %%
        if m_tilde>M_tilde && m_tilde_Identity(m_tilde)==0 && (O(m_tilde,n_frame)==1 || O(m_tilde,n_frame)==-1)
            l_nframe(m_tilde)=l_nframe(m_tilde)+1;
            if l_nframe(m_tilde)>=L_frame
                m_tilde_Identity(m_tilde)=1;
                J_hat(m_tilde)=J_hat(m_tilde)+1;
                % 
                [U_tilde,J_hat]=ObtainIdentity(A,U_tilde,J_hat,m_tilde,n_frame,L_frame,periodicity,ADC_samples,Num_chirp,N_range,N_doppler,Range_resolution,Doppler_resolution,T,Y_breve,Range_max,AoA,N_Theta);                
                % 
                R_bar_U=zeros(3,M_tilde);
                if M_tilde_noid>1
                    for m_tilde2=1:M_tilde_noid-1                        
                        if O(m_tilde2,n_frame-L_frame+1:n_frame)==0
                            R_bar_U(1:3,m_tilde2)=abs(U_tilde(1:3,m_tilde2,J_hat(m_tilde2))-U_tilde(1:3,m_tilde,J_hat(m_tilde)));
                        end
                    end
                    if R_bar_U~=0
                        R_bar_U_sum=sum(R_bar_U,1);
                        [R_bar_U_minvalue,R_bar_U_minindex]=min(R_bar_U_sum,[],2);
                        if R_bar_U(1,R_bar_U_minindex)<R_bar_U_T(1) && R_bar_U(2,R_bar_U_minindex)<R_bar_U_T(2) && R_bar_U(3,R_bar_U_minindex)<R_bar_U_T(3)
                            Y_breve(1:4,R_bar_U_minindex,n_frame-L_frame+1:frame)=Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame);
                            Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame)=0;                            
                            R_tilde(1:4,R_bar_U_minindex,n_frame-L_frame+1:frame)=R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame);
                            R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                            O(R_bar_U_minindex,n_frame-L_frame+1:frame)=O(m_tilde,n_frame-L_frame+1:frame);
                            O(m_tilde,n_frame-L_frame+1:frame)=0;l_nframe(m_tilde)=0;
                            J_hat(R_bar_U_minindex)=J_hat(R_bar_U_minindex)+1;
                            U_tilde(1:3,R_bar_U_minindex,J_hat(R_bar_U_minindex))=U_tilde(1:3,m_tilde,J_hat(m_tilde));
                            U_tilde(1:3,m_tilde,J_hat(m_tilde))=0;J_hat(m_tilde)=0;
                            m_tilde_Identity(m_tilde)=0;
                        else 
                            Y_breve(1:4,M_tilde_noid,n_frame-L_frame+1:frame)=Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame);
                            Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                            R_tilde(1:4,M_tilde_noid,n_frame-L_frame+1:frame)=R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame);
                            R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                            O(M_tilde_noid,n_frame-L_frame+1:frame)=O(m_tilde,n_frame-L_frame+1:frame);
                            O(m_tilde,n_frame-L_frame+1:frame)=0;
                            J_hat(M_tilde_noid)=J_hat(M_tilde_noid)+1;
                            U_tilde(1:3,M_tilde_noid,J_hat(M_tilde_noid))=U_tilde(1:3,m_tilde,J_hat(m_tilde));
                            U_tilde(1:3,m_tilde,J_hat(m_tilde))=0;J_hat(m_tilde)=0;
                            M_tilde_noid=M_tilde_noid+1;l_nframe(m_tilde)=0;
                            m_tilde_Identity(m_tilde)=0;
                        end
                    else
                        Y_breve(1:4,M_tilde_noid,n_frame-L_frame+1:frame)=Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame);
                        Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                        R_tilde(1:4,M_tilde_noid,n_frame-L_frame+1:frame)=R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame);
                        R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                        O(M_tilde_noid,n_frame-L_frame+1:frame)=O(m_tilde,n_frame-L_frame+1:frame);
                        O(m_tilde,n_frame-L_frame+1:frame)=0;
                        J_hat(M_tilde_noid)=J_hat(M_tilde_noid)+1;
                        U_tilde(1:3,M_tilde_noid,J_hat(M_tilde_noid))=U_tilde(1:3,m_tilde,J_hat(m_tilde));
                        U_tilde(1:3,m_tilde,J_hat(m_tilde))=0;J_hat(m_tilde)=0;
                        M_tilde_noid=M_tilde_noid+1;l_nframe(m_tilde)=0;
                        m_tilde_Identity(m_tilde)=0;
                    end
                else
                    Y_breve(1:4,M_tilde_noid,n_frame-L_frame+1:frame)=Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame);
                    Y_breve(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                    R_tilde(1:4,M_tilde_noid,n_frame-L_frame+1:frame)=R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame);
                    R_tilde(1:4,m_tilde,n_frame-L_frame+1:frame)=0;
                    O(M_tilde_noid,n_frame-L_frame+1:frame)=O(m_tilde,n_frame-L_frame+1:frame);
                    O(m_tilde,n_frame-L_frame+1:frame)=0;
                    J_hat(M_tilde_noid)=J_hat(M_tilde_noid)+1;
                    U_tilde(1:3,M_tilde_noid,J_hat(M_tilde_noid))=U_tilde(1:3,m_tilde,J_hat(m_tilde));
                    U_tilde(1:3,m_tilde,J_hat(m_tilde))=0;J_hat(m_tilde)=0;
                    M_tilde_noid=M_tilde_noid+1;l_nframe(m_tilde)=0;
                    m_tilde_Identity(m_tilde)=0;
                end
            end            
        elseif m_tilde>M_tilde && m_tilde_Identity(m_tilde)==0 && (O(m_tilde,n_frame)==0 || O(m_tilde,n_frame)==2)
            l_nframe(m_tilde)=0;
        end
    end
    %% Determine if occur the close interaction
    for m_tilde=1:M_tilde-1
        for m_tilde1=m_tilde+1:M_tilde
            if Y_breve(1,m_tilde,n_frame)~=0 && Y_breve(2,m_tilde,n_frame)~=0 && Y_breve(1,m_tilde1,n_frame)~=0 && Y_breve(2,m_tilde1,n_frame)~=0
                R_bar=abs(Y_breve(1:2,m_tilde,n_frame)-Y_breve(1:2,m_tilde1,n_frame));
                if R_bar(1)<r1(1) && R_bar(2)<r1(2)
                    Q_tilde(m_tilde,m_tilde1,n_frame)=1;
                    O(m_tilde,n_frame)=2;
                    O(m_tilde1,n_frame)=2;
                    J_hat(m_tilde)=J_hat(m_tilde)+1;
                    m_tilde_Identity(m_tilde)=0;
                    J_hat(m_tilde1)=J_hat(m_tilde1)+1;
                    m_tilde_Identity(m_tilde1)=0;         
                end
            end
        end       
        % 
        if m_tilde_Identity(m_tilde)==0 && (O(m_tilde,n_frame)==1 || O(m_tilde,n_frame)==-1)
            l_nframe(m_tilde)=l_nframe(m_tilde)+1;
            if l_nframe(m_tilde)>=L_frame+L_jiaohuframe 
                [U_tilde,J_hat]=ObtainIdentity(A,U_tilde,J_hat,m_tilde,n_frame,L_frame,periodicity,ADC_samples,Num_chirp,N_range,N_doppler,Range_resolution,Doppler_resolution,T,Y_breve,Range_max,AoA,N_Theta);                
                R_bar_U=zeros(3,M_tilde);
                for m_tilde3=1:M_tilde
                    if m_tilde_Identity(m_tilde3)==0
                        R_bar_U(1:3,m_tilde3)=abs(U_tilde(1:3,m_tilde,J_hat(m_tilde))-U_tilde(1:3,m_tilde3,1));
                    end
                end
                R_bar_U_sum=sum(R_bar_U,1);
                R_bar_U_index=find(R_bar_U_sum~=0);
                R_bar_U_minvalue=R_bar_U_sum(R_bar_U_index(1));R_bar_U_minindex=R_bar_U_index(1);
                for m_tilde3=2:length(R_bar_U_index)
                    if R_bar_U_sum(m_tilde3)<R_bar_U_minvalue
                        R_bar_U_minindex=R_bar_U_index(m_tilde3);
                    end
                end
                if R_bar_U(1,R_bar_U_minindex)<R_bar_U_T(1) && R_bar_U(2,R_bar_U_minindex)<R_bar_U_T(2) && R_bar_U(3,R_bar_U_minindex)<R_bar_U_T(3)
                    Y_check=Y_breve(1:4,R_bar_U_minindex,n_frame-(L_frame+L_jiaohuframe)+1:frame);
                    Y_breve(1:4,R_bar_U_minindex,n_frame-(L_frame+L_jiaohuframe)+1:frame)=Y_breve(1:4,m_tilde,n_frame-(L_frame+L_jiaohuframe)+1:frame);
                    Y_breve(1:4,m_tilde,n_frame-(L_frame+L_jiaohuframe)+1:frame)=Y_check;
                    R_check=R_tilde(1:4,R_bar_U_minindex,n_frame-(L_frame+L_jiaohuframe)+1:frame);
                    R_tilde(1:4,R_bar_U_minindex,n_frame-(L_frame+L_jiaohuframe)+1:frame)=R_tilde(1:4,m_tilde,n_frame-(L_frame+L_jiaohuframe)+1:frame);
                    R_tilde(1:4,m_tilde,n_frame-(L_frame+L_jiaohuframe)+1:frame)=R_check;
                    O_check=O(R_bar_U_minindex,n_frame-(L_frame+L_jiaohuframe)+1:frame);
                    O(R_bar_U_minindex,n_frame-(L_frame+L_jiaohuframe)+1:frame)=O(m_tilde,n_frame-(L_frame+L_jiaohuframe)+1:frame);
                    O(m_tilde,n_frame-(L_frame+L_jiaohuframe)+1:frame)=O_check;
                    m_tilde_Identity(R_bar_U_minindex)=1;
                    l_nframe_check=l_nframe(R_bar_U_minindex);
                    l_nframe(R_bar_U_minindex)=0;
                    if length(find(m_tilde_Identity(1:M_tilde)==0))==1
                        m_tilde_Identity(m_tilde)=1;
                        l_nframe(m_tilde)=0;
                    else
                        l_nframe(m_tilde)=l_nframe_check;
                    end
                end
            end
        elseif m_tilde_Identity(m_tilde)==0 && (O(m_tilde,n_frame)==0 || O(m_tilde,n_frame)==2)
            l_nframe(m_tilde)=0;            
        end
    end
end

figure; 
for n_frame=n_startframe:n_frame1
    for m_tilde=1:M_tilde+M_breve
        if O(m_tilde,n_frame)==1 || O(m_tilde,n_frame)==-1
            plot(Y_breve(1,m_tilde,n_frame),Y_breve(2,m_tilde,n_frame),b(1, (m_tilde-1)*2+1:m_tilde*2));hold on
            ylim([1*Range_resolution,N_range*Range_resolution]);
            xlim([AoA(1), AoA(N_Theta)]);
            set(gca,'FontName','Times New Roman','fontsize',13)
            title('RAM', 'fontsize', 20);
            xlabel('AoA (degree)', 'fontsize', 20);
            ylabel('Range (m)', 'fontsize', 20);
        end
    end
end

% dataname_Q='trajectory\';file_name='Y_breve\';
% ma=strcat(location,dataname_Q,file_name);mkdir(ma);
% save(strcat(ma,name,'.mat'), 'Y_breve');
% 
% dataname_Q='trajectory\';file_name='O\';
% ma=strcat(location,dataname_Q,file_name);mkdir(ma);
% save(strcat(ma,name,'.mat'), 'O');