function [M3]=Dopplerfft(Range_resolution,N_range,Num_chirp,N_doppler,M1_all,T,Range_chirp,kStep)
D = Num_chirp;  
M3=[];
l =1;
for i=1:kStep:(size(M1_all,2)-D+1)  
    M1=M1_all(:,i+(0:(D-1))); 
    range_tminindex=max(round((Range_chirp(i)-1.6)/Range_resolution),1);
    range_tmaxindex=min(round((Range_chirp(i)+1.6)/Range_resolution),N_range);
    M2=M1(range_tminindex:range_tmaxindex,:); 
    M20=M2.';
    win = hamming(size(M20, 1));   
    M20= (M20).*(win*ones(1,size(M20, 2)));
    M21=fftshift(fft(M20,N_doppler),1);
    M21 = (abs(M21)).^2;
    M3(:,l)=sum(M21,2);
    l = l+1;
end
end