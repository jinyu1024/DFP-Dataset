function [M1,M1_abs]=Rangefft(Rawdata,Num_chirp,N_range,Range_resolution,T,D,n_frame,periodicity)
win = hamming(size(Rawdata, 1));
Rawdata = (Rawdata).*(win*ones(1,size(Rawdata, 2)));
%% 
M1=fft(Rawdata,N_range);
%% 
for i=1:D
    M1_frame=M1(:,(i-1)*Num_chirp+1:i*Num_chirp);
    avg = sum(M1_frame,2)/Num_chirp;
    for chirp=1:Num_chirp
        M1_frame(:,chirp) = M1_frame(:,chirp)-avg;
    end
    M1(:,(i-1)*Num_chirp+1:i*Num_chirp)=M1_frame;
end
%% 
M1_abs = abs(M1);