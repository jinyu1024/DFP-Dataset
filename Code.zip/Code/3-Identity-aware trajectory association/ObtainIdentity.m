function [U_tilde,J_hat]=ObtainIdentity(A,U_tilde,J_hat,m_tilde,n_frame,L_frame,periodicity,ADC_samples,Num_chirp,N_range,N_doppler,Range_resolution,Doppler_resolution,T,Y_breve,Range_max,AoA,N_Theta)
    for channel=1:8 
        A_frame=A(channel,(n_frame-L_frame)*ADC_samples*Num_chirp+1:(n_frame)*ADC_samples*Num_chirp);
        Rawdata=reshape(A_frame,ADC_samples,[]);
        [M1,M1_abs]=Rangefft(Rawdata,Num_chirp,N_range,Range_resolution,T,L_frame,n_frame-L_frame+1,periodicity);
        M1_1(channel,:)=reshape(M1,1,[]);
    end
    %
    for n_frame2=1:L_frame
        AoA_frame(n_frame2)=Y_breve(1,m_tilde,n_frame-L_frame+n_frame2);
        Range_frame(n_frame2)=Y_breve(2,m_tilde,n_frame-L_frame+n_frame2);
    end
    x=[];y=[];
    x=1:L_frame;
    y=Range_frame;
    y1=curvefitting(x,y,1);
    Range_frame_fit=y1;
    %
    x=[];y=[];
    x=1:L_frame;
    y=AoA_frame;
    y1=curvefitting(x,y,3);
    AoA_frame_fit=y1;
    %
    for n_frame2=1:L_frame
        H=M1_1(:,(n_frame2-1)*N_range*Num_chirp+1:n_frame2*N_range*Num_chirp);nTx=8;
        theta=AoA_frame_fit(n_frame2);
        [H1,Power]=Beamforming(H, nTx, theta);
        M1_2(:,(n_frame2-1)*Num_chirp+1:n_frame2*Num_chirp)=reshape(H1,N_range,[]);
        Range_chirp((n_frame2-1)*Num_chirp+1:n_frame2*Num_chirp)=Range_frame_fit(n_frame2);
    end
    %
    kStep=96;
    [M2]=Dopplerfft(Range_resolution,N_range,Num_chirp,N_doppler,M1_2,T,Range_chirp,kStep);
    m=size(M2,1);
    n=size(M2,2);
    doppler=linspace(-m/2+1,m/2,m);
    periodicity1=periodicity*L_frame/n;
    start_doppler_Time=floor((n_frame-L_frame+1)*periodicity/periodicity1);
    doppler_Time1=linspace(1,n,n)+start_doppler_Time;
    %% 
    [M,yf] = max(M2);
    Doppler_target=doppler(yf)*Doppler_resolution;
    %
    x=[];y=[];
    x=doppler_Time1;
    y=Doppler_target;
    y1=curvefitting(x,y,20);
    Doppler_target_fit=y1;
    % 
    if max(abs(AoA_frame_fit))<10
        rate(1,1:L_frame)=1;
    else
        jiange_frame=1;
        for n_frame2=1:L_frame
            if n_frame2<=L_frame-jiange_frame
                rate(1,n_frame2)=sqrt((Range_frame_fit(n_frame2+jiange_frame))^2+(Range_frame_fit(n_frame2))^2-2*Range_frame_fit(n_frame2)*Range_frame_fit(n_frame2+jiange_frame)*cos(AoA_frame_fit(1,n_frame2+jiange_frame)*pi/180-AoA_frame_fit(1,n_frame2)*pi/180))/abs(Range_frame_fit(n_frame2+jiange_frame)-Range_frame_fit(n_frame2));
            elseif n_frame2>L_frame-jiange_frame
                rate(1,n_frame2)=rate(1,n_frame2-jiange_frame);
            end
        end
    end
    % 
    n_dopplerframe=0;
    for n_chirp=1:kStep:size(M1_2,2)-Num_chirp+1
        n_dopplerframe=n_dopplerframe+1;
        Doppler_target_actual(1,n_dopplerframe)=Doppler_target(1,n_dopplerframe)*rate(1,floor(n_chirp/255)+1);
    end
    % 
    x=[];y=[];
    x=doppler_Time1;
    y=Doppler_target_actual;
    y1=curvefitting(x,y,20);
    Doppler_target_actual_fit=y1;
    if mean(Doppler_target_actual_fit)<0
        Doppler_target_actual_fit=-Doppler_target_actual_fit;
        y=-y;y1=-y1;
    end
    % 
    [v_norm,locs,loc_min,amplitude,y_mean]=normalization(doppler_Time1,Doppler_target_actual_fit,size(Doppler_target_actual_fit,2),periodicity1);
    loc=[locs,loc_min];
    loc=sort(loc);
    gaitstep=sum(loc(2:size(loc,2))-loc(1:size(loc,2)-1))/(size(loc,2)-1);
    U_tilde(1:3,m_tilde,J_hat(m_tilde))=[y_mean;amplitude;gaitstep*periodicity1];
end